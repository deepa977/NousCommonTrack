function changeColor(colorCode){
    if(colorCode==1){
        document.bgColor="red";
    }else if(colorCode==2){
        document.bgColor="green";
    }else{
        document.bgColor="blue";
    }
}
function incrementSize(){
    x.style.fontSize="30pt";
    x.style.color="red";
}

function decrementSize(){
    x.style.fontSize="12pt";
    x.style.color="black";
}